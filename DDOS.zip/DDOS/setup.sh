echo -e "\x1b[1;34m[+] install golang"
pkg install golang
pkg install figlet 
echo -e "\x1b[1;34m[✓] ALQADHI_HK TOOL DOWNLOADED"
